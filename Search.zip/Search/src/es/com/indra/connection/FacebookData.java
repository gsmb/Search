package es.com.indra.connection;

public class FacebookData {
	
	
	private String username;
	private String userbirth;
	private String userrelationshipstatus;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserbirth() {
		return userbirth;
	}
	public void setUserbirth(String userbirth) {
		this.userbirth = userbirth;
	}
	public String getUserrelationshipstatus() {
		return userrelationshipstatus;
	}
	public void setUserrelationshipstatus(String userrelationshipstatus) {
		this.userrelationshipstatus = userrelationshipstatus;
	}

}
